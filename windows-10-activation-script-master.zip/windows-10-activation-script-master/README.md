# windows-10-activation-script

Run the bat file as administrator to activate your copy of windows.

WIN 10 ALL IN ONE

https://github.com/DONPAUL1299/WINDOWS-10-ACTIVATION-KEY.git